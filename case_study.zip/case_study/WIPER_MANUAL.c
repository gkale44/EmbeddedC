
#include "WIPER_AUTO.h"
#include "WIPER_MANUAL.h"
#include "GPIO.h"

#include<avr/io.h>
#include<avr/interrupt.h>
#include<util/delay.h>

void WIPER_MANUAL()
{
    OCR0A=128; //50% duty cycle
    //_delay_ms(1000);
    /*TCCR0A |= ((1<< WGM01) | (1 << WGM00));
    TCCR0A |=(1 << COM0A1);
    TCCR0A |=(1 << COM0A0);
    TCNT0 = 0x00;
    OCR0A = 128;
    TCCR0B |= ((1 << CS02) | (1 << CS01));
    TCCR0B &= (1 <<CS01);
    sei();
    _delay_ms(10000);
    TCCR0B = 0x00;*/

}
