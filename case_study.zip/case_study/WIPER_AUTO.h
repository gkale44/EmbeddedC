
#ifndef WIPER_AUTO_H_INCLUDED
#define WIPER_AUTO_H_INCLUDED

#include "GPIO.h"
#include "WIPER_AUTO.h"
#endif // GPIO_H_INCLUDED


